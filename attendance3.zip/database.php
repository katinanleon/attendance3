<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$db="student_attendance";
	$conn = mysqli_connect($servername, $username, $password,$db);
?>