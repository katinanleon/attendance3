<!DOCTYPE html>
<html>
<head>

	<title>Student</title>
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link rel="stylesheet" type="text/css" href="style.css">
<!------ Include the above in your HEAD tag ---------->
</head>
<body class="container bg-secondary">


    <h1 class="text-center">STUDENT ATTENDANCE</h1>

	
	<div class="container">
	<div class="row">
	
	<!--team-1-->
	<div class="col-lg-4">
	<div >
	
	<div>
	
	
	<h3></h3>
	
	</div>
	
	<div class=>
	<span>
	
	</span>
	</div>
	
	</div>
	</div>
	<!--team-1-->
	
	<!--team-2-->
	<div class="col-lg-4">
	<div class="our-team-main">
	
	<div class="team-front">
	<img src="http://placehold.it/110x110/336699/fff?text=Teacher" class="img-fluid" />
	<h3>Teacher Login</h3>
	
	</div>
	
	<div class="team-back">
	<span>
	<a href="teachlogin.php" class="text-info">Teacher</a>
	</span>
	</div>
	
	</div>
	</div>
	<!--team-2-->
	
	<!--team-3-->
	<div class="col-lg-4">
	<div >
	
	<div >
	
	<h3></h3>
	
	</div>
	
	<div >
	<span>
	
	</span>
	</div>
	
	</div>
	</div>






</body>
</html>




	
	
	
	
	
	