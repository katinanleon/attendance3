<?php
include 'database.php';
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Signature</title>
</head>
<body>
<h1>Thank you for signing Up to day </h1>


<SCRIPT LANGUAGE="JavaScript">
var maintenant=new Date();
document.write(maintenant);
</SCRIPT>
<br>


<br>
<br>
<div>
<button type="button" class="btn btn-primary btn-lg"><a href="index.php">OK</a></button>

</div><br>

<div>
<button type="button" class="btn btn-primary btn-lg"><a href="profil.php">prof's</a></button>

</div




<?php
    
  // le script qui permet de signer une fois

       $email = $_SESSION["email"];
    $dup = mysqli_query($conn,"select * from student where email = '$email'");
      $row = mysqli_fetch_assoc($dup);
      $id = $row["id"];
      $_SESSION["id"]= $row["id"];
      $_SESSION["name"]= $row["name"];
      $_SESSION["tel"]= $row["tel"];
      $_SESSION["sex"]= $row["sex"];
      $_SESSION["file_name"]= $row["file_name"];

    // $date = date("Y-m-d");

    // $verif = mysqli_query($conn,"SELECT iduser,datesign, statut FROM attendance WHERE iduser='$id' AND datesign='$date'");
    // // var_dump($verif);
    // // var_dump(mysqli_num_rows($verif));

    // if(mysqli_num_rows($verif)==1){

    //          $insertion = "UPDATE attendance SET statut='present' WHERE iduser= '$id' AND statut = 'abscent' AND datesign = $date";
    //   mysqli_query($conn, $insertion);
    // }
    // else{
    //     echo "vous avez déja signé";

    // }    

    $date = date("Y-m-d");


    $verif = mysqli_query($conn, "SELECT iduser, datesign, statut, cours FROM attendance WHERE iduser='$id' AND datesign='$date'");
    if (mysqli_num_rows($verif) == 0) {

        echo "Le cours n'est pas encore";
    }
    else{
        $row_verif= mysqli_fetch_assoc($verif);
        $cours = $row_verif["cours"];

        $statut = $row_verif["statut"];
        if ($cours == 1) {
            echo "le cours est fini";
        } else {
            if (mysqli_num_rows($verif) == 1 && $statut != 'present') {
                $insertion = "UPDATE attendance SET statut='present' WHERE iduser= '$id' AND datesign = '$date' ";
                mysqli_query($conn, $insertion);
                echo "bien";
            } else {
                if (mysqli_num_rows($verif) == 0) {
                    echo "le cours n'a pas encore débuté";
                } else {
                    echo "Vous avez déjà signé";
                    echo "le cours est fini";
                }
            }
        }
    }

   
 ?>